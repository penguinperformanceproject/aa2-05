
1.0.0 / 2013-01-24 
==================

  * remove lame magical getters

0.0.1 / 2010-01-03
==================

  * Initial release
